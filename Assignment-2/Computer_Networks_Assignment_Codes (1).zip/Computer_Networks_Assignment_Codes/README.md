# Computer Networks Assignment – Q1 to Q7 Code Package

This package contains Python 3 programs and Cisco IOS configuration examples based on the uploaded assignment.

## Requirements
- Python 3.8 or later
- Cisco Packet Tracer for `.txt` router configuration examples

## Run Python programs
Open a terminal in this folder and run:

```bash
python q1_addressing_nat.py
python q2_vlsm.py
python q3_longest_prefix.py
python q4_distance_vector.py
python q5_ospf_dijkstra.py
python q6_ipv6_multicast.py
python q7_redesign_validation.py
```

## Files
- `q1_addressing_nat.py` – IPv4 network/broadcast/host calculations and PAT example
- `q2_vlsm.py` – VLSM allocation and hostel subnet validation
- `q3_longest_prefix.py` – longest-prefix matching
- `q3_R1_config.txt`, `q3_R2_config.txt` – static routing configuration examples
- `q3_floating_static_route.txt` – floating static route example
- `q4_distance_vector.py` – Bellman-Ford distance-vector exchange
- `q4_RIP_config.txt` – RIP v2 configuration example
- `q5_ospf_dijkstra.py` – OSPF cost calculations and Dijkstra shortest path
- `q5_OSPF_config.txt` – OSPF reference-bandwidth configuration example
- `q6_ipv6_multicast.py` – IPv6 shortening, modified EUI-64 and multicast MAC calculation
- `q7_redesign_validation.py` – validates redesigned campus subnets

## Important notes
- The assignment's Q2 expected VLSM allocation leaves the remaining addresses fragmented. A 60-host `/26` cannot fit in the remaining 28 addresses. The redesign example places the hostel at `192.168.11.0/26` inside the expanded `192.168.10.0/23` block.
- For Q3, the floating static route needs a separately configured, reachable backup next hop and backup link. The example command is a template; change the next hop to match your Packet Tracer topology.
- For serial links, set `clock rate` only on the DCE side.
- Packet Tracer interface names may differ by router model. Check available interfaces with `show ip interface brief`.
