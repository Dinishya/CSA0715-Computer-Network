import ipaddress

devices = [
    ("Admission PC", "172.16.45.200/20"),
    ("Lab printer", "10.0.15.255/21"),
    ("X-ray server", "192.168.4.0/23"),
    ("Clinic router", "203.0.113.10/29"),
]

print("Q1 - IPv4 address validation")
for name, address in devices:
    interface = ipaddress.ip_interface(address)
    network = interface.network
    ip = interface.ip
    valid = ip != network.network_address and ip != network.broadcast_address
    print(f"\n{name}: {ip}/{network.prefixlen}")
    print("Network:", network.network_address)
    print("Broadcast:", network.broadcast_address)
    print("Usable range:", list(network.hosts())[0], "-", list(network.hosts())[-1])
    print("Valid host address:", "Yes" if valid else "No")

print("\nExample PAT/NAT translation table")
print(f"{'Device':<8}{'Private source':<25}{'Public translated source'}")
translations = [
    ("PC1", "192.168.1.10:50000", "203.0.113.10:40001"),
    ("PC2", "192.168.1.11:50000", "203.0.113.10:40002"),
    ("PC3", "192.168.1.12:50000", "203.0.113.10:40003"),
]
for row in translations:
    print(f"{row[0]:<8}{row[1]:<25}{row[2]}")
