import ipaddress
import math

def allocate_vlsm(base, needs):
    current = int(ipaddress.ip_network(base, strict=True).network_address)
    end = int(ipaddress.ip_network(base, strict=True).broadcast_address)
    results = []

    for name, hosts in sorted(needs, key=lambda item: item[1], reverse=True):
        # Need network + broadcast addresses for ordinary IPv4 subnets.
        block_size = 1 << math.ceil(math.log2(hosts + 2))
        prefix = 32 - int(math.log2(block_size))

        # Align current address to the next block boundary.
        current = ((current + block_size - 1) // block_size) * block_size
        network = ipaddress.ip_network((current, prefix))

        if int(network.broadcast_address) > end:
            raise ValueError(f"Not enough space for {name} ({hosts} hosts)")

        results.append((name, network))
        current = int(network.broadcast_address) + 1

    return results, current

needs = [("Labs", 100), ("Staff", 50), ("Library", 25), ("WAN link", 2)]
allocated, next_free = allocate_vlsm("192.168.10.0/24", needs)

print("Q2 - VLSM allocation")
for name, net in allocated:
    hosts = list(net.hosts())
    print(f"{name:<10} {net}  mask {net.netmask}  "
          f"hosts {hosts[0]} - {hosts[-1]}  bcast {net.broadcast_address}")
print("Next free address:", ipaddress.ip_address(next_free))

print("\nHostel check (60 hosts needs /26):")
hostel_block = 64
remaining = int(ipaddress.ip_network("192.168.10.0/24").broadcast_address) - next_free + 1
print("Remaining addresses in original /24:", max(0, remaining))
print("Required addresses for /26:", hostel_block)
print("Can fit in remaining contiguous space:", remaining >= hostel_block)

print("\nExpanded /23 redesign:")
expanded = ipaddress.ip_network("192.168.10.0/23")
hostel = ipaddress.ip_network("192.168.11.0/26")
print("Expanded block:", expanded)
print("Hostel subnet:", hostel)
print("Hostel usable hosts:", hostel.num_addresses - 2)
print("Hostel subnet contained in expanded block:", hostel.subnet_of(expanded))

print("\nRoute summarisation:")
nets = [ipaddress.ip_network(f"172.16.{n}.0/24") for n in range(8, 12)]
print("Summary for 172.16.8.0/24 through 172.16.11.0/24:",
      ipaddress.collapse_addresses(nets))
