import ipaddress

routes = [
    ("10.0.0.0/8", "192.0.2.1"),
    ("10.1.0.0/16", "192.0.2.5"),
    ("10.1.2.0/24", "192.0.2.9"),
    ("10.1.2.128/25", "192.0.2.13"),
    ("0.0.0.0/0", "198.51.100.1"),
]

def next_hop(destination):
    address = ipaddress.ip_address(destination)
    matches = [(ipaddress.ip_network(net), hop)
               for net, hop in routes
               if address in ipaddress.ip_network(net)]
    best_network, best_hop = max(matches, key=lambda item: item[0].prefixlen)
    return best_network, best_hop

destinations = ["10.1.2.200", "10.1.2.100", "10.1.9.9",
                "10.7.7.7", "8.8.8.8"]

print("Q3 - Longest-prefix matching")
for destination in destinations:
    network, hop = next_hop(destination)
    print(f"{destination:<15} -> {str(network):<18} next hop {hop}")
