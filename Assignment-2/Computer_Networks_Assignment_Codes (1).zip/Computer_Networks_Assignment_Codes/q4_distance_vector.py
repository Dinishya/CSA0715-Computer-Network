INF = 99
names = "ABCDE"

cost = {
    ("A", "B"): 2,
    ("A", "C"): 7,
    ("B", "C"): 3,
    ("B", "D"): 8,
    ("C", "D"): 1,
    ("D", "E"): 4
}

def build_links(costs):
    links = {}
    for (u, v), value in costs.items():
        links[(u, v)] = value
        links[(v, u)] = value
    return links

def distance_vector(costs):
    links = build_links(costs)
    table = {
        u: {v: (0 if u == v else links.get((u, v), INF)) for v in names}
        for u in names
    }

    rounds = 0
    changed = True
    while changed:
        changed = False
        rounds += 1
        old = {u: dict(table[u]) for u in names}

        for u in names:
            for neighbour in names:
                if (u, neighbour) not in links:
                    continue
                for destination in names:
                    new_cost = links[(u, neighbour)] + old[neighbour][destination]
                    if new_cost < table[u][destination]:
                        table[u][destination] = new_cost
                        changed = True

    return rounds, table

def print_table(rounds, table):
    print(f"Converged after {rounds} rounds")
    print("    " + " ".join(names))
    for router in names:
        print(router, "  " + " ".join(f"{table[router][dest]:2d}" for dest in names))

print("Q4 - Original network")
rounds, table = distance_vector(cost)
print_table(rounds, table)

print("\nAfter C-D link failure")
failed_cost = dict(cost)
failed_cost.pop(("C", "D"))
rounds, table = distance_vector(failed_cost)
print_table(rounds, table)
