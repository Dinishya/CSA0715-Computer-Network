import heapq

def ospf_cost(reference_mbps, link_mbps):
    return max(1, int(reference_mbps / link_mbps))

print("Q5 - OSPF costs")
speeds = [10, 100, 1000, 10000]
for reference in (100, 10000):
    print(f"\nReference bandwidth: {reference} Mbps")
    for speed in speeds:
        print(f"{speed:>5} Mbps -> cost {ospf_cost(reference, speed)}")

# Example six-router weighted topology.
# Replace/add links to match the topology drawn in your report.
graph = {
    "R1": {"R2": 10, "R3": 20},
    "R2": {"R1": 10, "R4": 10, "R5": 25},
    "R3": {"R1": 20, "R4": 5, "R6": 20},
    "R4": {"R2": 10, "R3": 5, "R5": 10, "R6": 15},
    "R5": {"R2": 25, "R4": 10, "R6": 5},
    "R6": {"R3": 20, "R4": 15, "R5": 5},
}

def dijkstra(graph, source):
    distances = {node: float("inf") for node in graph}
    previous = {node: None for node in graph}
    distances[source] = 0
    queue = [(0, source)]

    while queue:
        distance, node = heapq.heappop(queue)
        if distance != distances[node]:
            continue
        for neighbour, weight in graph[node].items():
            candidate = distance + weight
            if candidate < distances[neighbour]:
                distances[neighbour] = candidate
                previous[neighbour] = node
                heapq.heappush(queue, (candidate, neighbour))

    return distances, previous

distances, previous = dijkstra(graph, "R1")
print("\nDijkstra shortest distances from R1:")
for node in sorted(distances):
    print(f"R1 to {node}: {distances[node]}")
