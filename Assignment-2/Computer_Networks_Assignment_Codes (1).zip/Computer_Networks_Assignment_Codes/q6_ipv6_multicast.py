import ipaddress

def modified_eui64(mac):
    octets = [int(part, 16) for part in mac.split(":")]
    if len(octets) != 6:
        raise ValueError("MAC address must contain 6 octets")
    octets[0] ^= 0x02
    eui = octets[:3] + [0xFF, 0xFE] + octets[3:]
    return ":".join(f"{eui[i] << 8 | eui[i+1]:04x}" for i in range(0, 8, 2))

def ipv4_multicast_mac(ip):
    address = ipaddress.IPv4Address(ip)
    if not address.is_multicast:
        raise ValueError("Address is not IPv4 multicast")
    value = int(address) & 0x7FFFFF
    return "01:00:5e:" + ":".join(
        f"{(value >> shift) & 0xff:02x}" for shift in (16, 8, 0)
    )

ipv6 = ipaddress.IPv6Address("2001:0db8:0000:0000:0000:ff00:0042:8329")
print("Q6 - IPv6 and multicast")
print("Compressed IPv6:", ipv6.compressed)
print("Modified EUI-64:", modified_eui64("00:1A:2B:3C:4D:5E"))
print("Multicast MAC for 239.1.2.3:", ipv4_multicast_mac("239.1.2.3"))
print("6in4 packet size for 100-byte inner IPv6 packet:", 100 + 20, "bytes")
