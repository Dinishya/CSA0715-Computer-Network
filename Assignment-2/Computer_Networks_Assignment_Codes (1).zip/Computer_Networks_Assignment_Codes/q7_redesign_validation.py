import ipaddress

expanded = ipaddress.ip_network("192.168.10.0/23")
subnets = [
    ("Labs", "192.168.10.0/25"),
    ("Staff", "192.168.10.128/26"),
    ("Library", "192.168.10.192/27"),
    ("WAN", "192.168.10.224/30"),
    ("Hostel", "192.168.11.0/26"),
]

print("Q7 - Redesigned campus network validation")
print("Expanded address block:", expanded)

parsed = []
for name, cidr in subnets:
    net = ipaddress.ip_network(cidr, strict=True)
    if not net.subnet_of(expanded):
        raise ValueError(f"{name} subnet is outside expanded block")
    parsed.append((name, net))
    hosts = list(net.hosts())
    print(f"\n{name}: {net}")
    print("Mask:", net.netmask)
    print("First host:", hosts[0])
    print("Last host:", hosts[-1])
    print("Broadcast:", net.broadcast_address)
    print("Usable host count:", len(hosts))

for i in range(len(parsed)):
    for j in range(i + 1, len(parsed)):
        if parsed[i][1].overlaps(parsed[j][1]):
            raise ValueError(f"Overlap: {parsed[i][0]} and {parsed[j][0]}")

print("\nValidation successful: all subnets are inside /23 and do not overlap.")
