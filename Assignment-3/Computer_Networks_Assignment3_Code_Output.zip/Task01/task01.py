# Q1: TCP/UDP demultiplexing and header overhead
connections = [
    ("TCP", "49.37.2.8:50001", "203.0.113.5:443", "established socket #1"),
    ("TCP", "117.96.4.2:50000", "203.0.113.5:443", "established socket #2"),
    ("TCP SYN", "106.51.7.7:41000", "203.0.113.5:443", "listening socket (new connection)"),
    ("UDP", "49.37.2.8:50000", "203.0.113.5:5004", "UDP socket bound to port 5004"),
]
for proto, src, dst, sock in connections:
    print(f"{proto}: {src} -> {dst} => {sock}")

udp_total = 100 + 20 + 8
tcp_total = 100 + 20 + 20
print(f"UDP total packet bytes: {udp_total}; overhead/data: {28/100*100:.1f}%")
print(f"TCP total packet bytes: {tcp_total}; overhead/data: {40/100*100:.1f}%")
