# Task 2 — Congestion Window
The script simulates Reno and Tahoe-style responses for losses at RTT 8 and 14 and estimates window-limited throughput at RTT 7.
Note: the exact trace depends on whether cwnd is recorded before or after each RTT update and on the loss recovery model. Use the exact loss events and code specified by your assignment handout.
