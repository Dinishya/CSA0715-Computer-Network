# Q2: Simple congestion-window simulation with losses at RTT 8 and 14
def simulate(reno=True, rounds=20, losses=(8, 14)):
    cwnd, ssthresh = 1, 16
    trace, total = [], 0
    for rtt in range(1, rounds + 1):
        trace.append(cwnd)
        total += cwnd
        if rtt in losses:
            ssthresh = max(cwnd // 2, 2)
            cwnd = ssthresh if reno else 1
        elif cwnd < ssthresh:
            cwnd = min(cwnd * 2, ssthresh)
        else:
            cwnd += 1
    return trace, total

for name, is_reno in [("Reno", True), ("Tahoe", False)]:
    trace, total = simulate(is_reno)
    print(name, "trace:", " ".join(map(str, trace)))
    print(name, "segments sent:", total)

# Window-limited throughput at RTT 7: 18 segments, MSS 1460 bytes, RTT 40 ms
bps = 18 * 1460 * 8 / 0.04
print(f"RTT7 throughput: {bps/1e6:.3f} Mbps")
