# Q3: HTTP load-time estimates; RTT=50 ms, HTML + 80 objects
rtt = 0.05
objects = 81
nonpersistent = objects * 2 * rtt
persistent_no_pipeline = (2 + 80) * rtt
persistent_pipeline = 3 * rtt
six_parallel = 2*rtt + ((80 + 5)//6) * 2*rtt
bundled_nonpersistent = 9 * 2*rtt
bundled_persistent = (2 + 8) * rtt
print(f"Non-persistent sequential: {nonpersistent:.2f} s")
print(f"Persistent, no pipelining: {persistent_no_pipeline:.2f} s")
print(f"Persistent with pipelining: {persistent_pipeline:.2f} s")
print(f"6 parallel non-persistent connections: {six_parallel:.2f} s")
print(f"8 bundles, non-persistent: {bundled_nonpersistent:.2f} s")
print(f"8 bundles, persistent no pipeline: {bundled_persistent:.2f} s")
