# Q4: DNS TTL refresh calculations and simple cached resolver demonstration
for ttl in (300, 30):
    print(f"TTL {ttl}s: {3600//ttl} refreshes/hour per resolver")

records = {
    "simats.ac.in": "10.20.30.40",
    "example.com": "93.184.216.34",
}
cache = {}
def resolve(name):
    if name in cache:
        return cache[name], 0
    suffix = max((s for s in records if name.endswith(s)), key=len)
    ip = records[suffix]
    cache[name] = ip
    return ip, 3

for name in ("results.simats.ac.in", "www.example.com", "results.simats.ac.in"):
    ip, queries = resolve(name)
    print(f"{name}: {ip}; queries sent: {queries}")
