# Q5: M/M/1 queue calculations and token bucket burst
mu = 1000
for lam in (500, 800, 900, 950, 990):
    rho = lam/mu
    L = rho/(1-rho)
    W = 1/(mu-lam)
    print(f"lambda={lam}: rho={rho:.2f}, L={L:.1f}, W={W*1000:.1f} ms")

bucket_bytes = 1_000_000
bucket_bits = bucket_bytes*8
excess_bps = (10-2)*1_000_000
print(f"Token bucket burst duration: {bucket_bits/excess_bps:.2f} s")

W = 1/(2000-1800)
print(f"Delay after doubling link capacity (lambda=1800, mu=2000): {W*1000:.1f} ms")
