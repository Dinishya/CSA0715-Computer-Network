# Q6: Approximate handshake RTT comparison, RTT=100 ms
rtt_ms = 100
cases = {
    "TCP + TLS 1.2 full handshake": 3,
    "TCP + TLS 1.3 full handshake": 2,
    "QUIC full handshake": 1,
    "QUIC 0-RTT early data setup": 0,
}
for label, rtts in cases.items():
    print(f"{label}: approx {rtts*rtt_ms} ms ({rtts} RTT)")
print("Reminder: 0-RTT early data is replayable; only replay-safe operations should use it.")
