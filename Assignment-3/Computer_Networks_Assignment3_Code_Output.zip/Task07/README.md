# Task 7 — Telemedicine protocol design
`task07.py` runs the throughput and image-transfer estimate.

The file sender/receiver are simple educational TCP examples. Place a test file named `sample_file.bin` in this folder, run `file_server.py` first and then `file_client.py`. Run only on your own computer or an authorized lab network. Add your own test evidence.
