# Educational TCP file sender. Place sample_file.bin beside this script.
import socket
HOST, PORT = "127.0.0.1", 5001
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
    client.connect((HOST, PORT))
    with open("sample_file.bin", "rb") as src:
        while True:
            chunk = src.read(4096)
            if not chunk:
                break
            client.sendall(chunk)
    client.shutdown(socket.SHUT_WR)
print("File sent.")
