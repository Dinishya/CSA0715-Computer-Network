# Educational TCP file receiver. Run server first, then file_client.py.
import socket
HOST, PORT = "127.0.0.1", 5001
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(1)
    print(f"File server listening on {HOST}:{PORT}")
    conn, addr = server.accept()
    with conn, open("received_file.bin", "wb") as out:
        print("Connected:", addr)
        while True:
            chunk = conn.recv(4096)
            if not chunk:
                break
            out.write(chunk)
    print("File received.")
