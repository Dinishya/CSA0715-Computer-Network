# Q7: Telemedicine network calculations
window_bytes = 64 * 1024
rtt_s = 0.300
throughput_bps = window_bytes * 8 / rtt_s
image_mb = 10
transfer_s = image_mb * 8 / (throughput_bps/1e6)
print(f"TCP window-limited throughput: {throughput_bps/1e6:.3f} Mbps")
print(f"Ideal 10 MB image transfer time: {transfer_s:.1f} s")
print("Design: RTP/UDP for live media; HTTPS/TLS over TCP or QUIC for records/images;")
print("reliable TLS-protected stream for chat; DNS caching; QoS EF for media, AF for records,")
print("best effort for backups.")
