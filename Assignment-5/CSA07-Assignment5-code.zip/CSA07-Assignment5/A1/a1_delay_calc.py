"""A1 - Delay breakdown and bandwidth-delay product."""
def delays(link_bps, size_bytes=1500, dist_km=2000, routers=3, q_ms=0.5, p_ms=0.1):
    tx = size_bytes * 8 / link_bps * 1000          # ms, one link
    prop = dist_km * 1000 / 2e8 * 1000             # ms, 2x10^8 m/s in fibre
    queue = routers * q_ms
    proc = routers * p_ms
    return tx, prop, queue, proc, tx + prop + queue + proc

for name, bps in (("100 Mbps", 100e6), ("1 Gbps", 1e9)):
    tx, prop, q, pr, tot = delays(bps)
    print(f"--- A1.1 links = {name} ---")
    print(f"transmission {tx:.3f} ms | propagation {prop:.3f} ms | queuing {q:.3f} ms | processing {pr:.3f} ms")
    print(f"TOTAL {tot:.3f} ms  (propagation share {prop/tot*100:.1f} %)")

print("\n--- A1.2 bandwidth-delay product ---")
bw, rtt = 1e9, 0.080
bdp_bits = bw * rtt
print(f"BDP = {bdp_bits/1e6:.0f} Mbit = {bdp_bits/8/1e6:.1f} MB")
win = 64 * 1024 * 8
thr = win / rtt
print(f"64 KB window -> max throughput = {thr/1e6:.2f} Mbps ({thr/bw*100:.2f} % of the link)")
print(f"Window needed to fill the link = {bdp_bits/8/1024:.0f} KB")
