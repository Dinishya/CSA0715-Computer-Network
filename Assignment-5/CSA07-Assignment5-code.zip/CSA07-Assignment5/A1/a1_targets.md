# A1.3 Targets and tools
| Application | One-way delay | Jitter | Loss | Throughput | Active tool | Passive tool |
|---|---|---|---|---|---|---|
| Live video | < 150 ms | < 30 ms | < 1 % | 1.5-4 Mbps/stream | iperf3 -u, ping | Wireshark RTP analysis |
| Voice (VoIP) | < 150 ms | < 30 ms | < 1 % | 80-90 kbps/call | ping, iperf3 -u -b 80k | Wireshark RTP streams |
| Recorded video | < 400 ms start-up | not critical | < 2 % | 3-5 Mbps | iperf3 TCP | SNMP interface counters |
| E-mail | seconds | n/a | 0 % (TCP) | < 1 Mbps | ping, traceroute | SNMP / server logs |
| File downloads | n/a | n/a | < 1 % | >= 50 Mbps per centre | iperf3 TCP | SNMP ifInOctets, Wireshark |
