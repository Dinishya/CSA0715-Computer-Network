# A2.2 / A2.3 commands to run and screenshot

## FTP passive vs active (needs a test FTP server, e.g. vsftpd in your lab)
    ftp -p <server>          # passive mode (client opens both connections)
    ftp -A <server>          # active mode (server connects back -> blocked by firewall)
    ftp> passive             # toggle

## SNMP GET and TRAP (net-snmp)
    snmpget  -v2c -c public 192.168.1.1 IF-MIB::ifInOctets.2
    snmpwalk -v2c -c public 192.168.1.1 IF-MIB::ifTable
    # receive traps on the manager
    sudo snmptrapd -f -Lo
    # send a linkDown trap from the "router"
    snmptrap -v2c -c public localhost '' 1.3.6.1.6.3.1.1.5.3 ifIndex i 2

## DNS and HTTP timings
    dig learn.example | grep "Query time"
    curl -o /dev/null -s -w "dns:%{time_namelookup} connect:%{time_connect} tls:%{time_appconnect} ttfb:%{time_starttransfer} total:%{time_total}\n" https://example.com
Browser: DevTools -> Network -> click a request -> Timing tab (DNS Lookup, Initial connection, SSL, Waiting (TTFB), Content Download).
