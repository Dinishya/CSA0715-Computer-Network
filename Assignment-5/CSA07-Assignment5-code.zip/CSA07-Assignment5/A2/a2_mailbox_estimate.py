"""A2 Alternative - data to open a 50-message mailbox: webmail (HTTPS) vs IMAP client.
Assumptions are explicit so they can be changed."""
N = 50
imap_envelope = 700          # bytes per message: UID, FLAGS, ENVELOPE, size, structure
imap_overhead = 3000         # login, SELECT, FETCH commands/responses (TLS records)
imap = N * imap_envelope + imap_overhead

webmail_page = 1_200_000     # first load: HTML + JS + CSS + fonts (bytes)
webmail_list_json = N * 600  # JSON row per message
webmail_first = webmail_page + webmail_list_json
webmail_cached = webmail_list_json + 20_000   # later visits, assets cached

print(f"IMAP client      : {imap/1024:8.1f} KB")
print(f"Webmail (first)  : {webmail_first/1024:8.1f} KB")
print(f"Webmail (cached) : {webmail_cached/1024:8.1f} KB")
