"""A2.1 - Show a real SMTP dialogue (EHLO, MAIL FROM, RCPT TO, DATA, QUIT).
Start a local debug server first (in another terminal):
    pip install aiosmtpd
    python -m aiosmtpd -n -l localhost:1025
Then run:  python a2_smtp_client.py   and screenshot the printed dialogue."""
import smtplib
from email.message import EmailMessage

msg = EmailMessage()
msg["From"] = "teacher@learn.example"
msg["To"] = "student@learn.example"
msg["Subject"] = "Class link"
msg.set_content("Live class starts at 6 pm.")

with smtplib.SMTP("localhost", 1025) as s:
    s.set_debuglevel(1)          # prints every command and reply code
    s.ehlo("client.learn.example")
    s.send_message(msg)          # MAIL FROM, RCPT TO, DATA
# leaving 'with' sends QUIT
