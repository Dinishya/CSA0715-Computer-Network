"""A3.1 - minimum distribution time, client-server vs P2P vs CDN."""
F = 4 * 8e9            # 4 GB in bits
N = 20
us, d, u = 100e6, 50e6, 20e6

cs = max(N * F / us, F / d)
p2p = max(F / us, F / d, N * F / (us + N * u))
print(f"Client-server : max({N*F/us:.0f}, {F/d:.0f}) = {cs:.0f} s = {cs/60:.1f} min")
print(f"Peer-to-peer  : max({F/us:.0f}, {F/d:.0f}, {N*F/(us+N*u):.0f}) = {p2p:.0f} s = {p2p/60:.1f} min")

# Alternative: CDN with a 1 Gbps edge server per region (edges already hold the file).
edge = 1e9
cdn = max(F / edge, F / d)        # each centre is limited by its own 50 Mbps download
print(f"CDN (edge cached): max({F/edge:.0f}, {F/d:.0f}) = {cdn:.0f} s = {cdn/60:.1f} min")
print(f"CDN one-time fill of 20 edges from origin at 100 Mbps: {N*F/us:.0f} s ({N*F/us/3600:.2f} h)")
