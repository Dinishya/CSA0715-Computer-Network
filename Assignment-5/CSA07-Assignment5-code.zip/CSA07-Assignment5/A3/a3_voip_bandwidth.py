"""A3.2 - real bandwidth of a G.711 call."""
codec_bps, ptime = 64000, 0.020
payload = codec_bps * ptime / 8            # bytes per packet
hdr = 40                                   # IP 20 + UDP 8 + RTP 12
pps = 1 / ptime
bw = (payload + hdr) * 8 * pps
print(f"payload {payload:.0f} B, packet {payload+hdr:.0f} B, {pps:.0f} packets/s")
print(f"bandwidth per direction (IP level) = {bw/1000:.1f} kbps")
link = 2e6
print(f"calls on 2 Mbps link: {int(link // bw)}")
bw_eth = (payload + hdr + 18) * 8 * pps     # + Ethernet header/FCS
print(f"with Ethernet framing {bw_eth/1000:.1f} kbps -> {int(link // bw_eth)} calls")
