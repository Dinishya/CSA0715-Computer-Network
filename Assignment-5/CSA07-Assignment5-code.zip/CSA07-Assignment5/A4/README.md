# A4 - how to run
Run the programs in this folder, save the console output as `output.txt`, add screenshots, captures and .pkt files here, then commit.
