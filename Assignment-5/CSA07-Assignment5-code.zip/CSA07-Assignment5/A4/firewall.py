"""A4 - A stateless packet filter: the first matching rule decides (like iptables)."""
RULES = [ # (action, protocol, destination port or None for any, source prefix or None)
    ("allow", "tcp", 443, None),
    ("allow", "tcp", 22, "10.1."),
    ("deny", "tcp", 22, None),
    ("allow", "udp", 53, None),
]
DEFAULT = "deny"

def decide(proto, port, src, rules=None):
    for action, p, dport, prefix in (rules or RULES):
        # TODO 1 (completed): protocol equal, port None or equal, prefix None or src starts with it
        if p == proto and (dport is None or dport == port) and (prefix is None or src.startswith(prefix)):
            return action
    return DEFAULT

packets = [("tcp", 443, "49.37.2.8"), ("tcp", 22, "10.1.4.20"),
           ("tcp", 22, "49.37.2.8"), ("udp", 53, "10.1.4.20"),
           ("tcp", 80, "49.37.2.8"), ("icmp", None, "49.37.2.8")]

def show(title, rules=None):
    print(f"== {title} ==")
    for pk in packets:
        print(f"{pk[0]:<5} {str(pk[1]):<5} from {pk[2]:<10} -> {decide(*pk, rules=rules)}")
    print()

if __name__ == "__main__":
    show("Corrected order")
    show("After swapping rules 2 and 3", [RULES[0], RULES[2], RULES[1], RULES[3]])
    faulty = [("allow","tcp",443,None), ("allow","tcp",22,None), ("deny","tcp",22,None),
              ("allow","tcp",22,"10.1."), ("allow","udp",53,None)]
    show("Original faulty rule set (SSH open to everyone)", faulty)
