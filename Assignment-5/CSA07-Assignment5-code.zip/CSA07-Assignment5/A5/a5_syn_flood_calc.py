"""A5 - size of a SYN flood."""
queue, hold = 1024, 60
rate = queue / hold
print(f"1 server : {queue} half-open / {hold} s = {rate:.1f} SYN/s to keep the queue full")
for n in (1, 4):
    print(f"{n} server(s): {n*queue} slots -> {n*queue/hold:.1f} SYN/s")
pkt = 60 * 8   # ~60-byte SYN
print(f"Bandwidth of {4*queue/hold:.0f} SYN/s = {4*queue/hold*pkt/1000:.1f} kbps - trivial for an attacker")
print("A botnet sending 100,000 SYN/s is", round(100000/(4*queue/hold)), "x what four servers can absorb")
