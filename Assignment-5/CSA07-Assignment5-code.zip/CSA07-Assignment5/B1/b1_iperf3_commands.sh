#!/bin/bash
# B1.2 - TCP and UDP throughput between two machines. Run the server on machine B first:
#   iperf3 -s
# Replace SERVER_IP and run on machine A. Repeat for wired and for wireless, save every output.
SERVER_IP=${1:-192.168.1.10}
mkdir -p iperf_results
for link in wired wireless; do
  read -p "Connect via $link then press Enter... "
  iperf3 -c $SERVER_IP -t 20            | tee iperf_results/${link}_tcp.txt
  iperf3 -c $SERVER_IP -t 20 -R         | tee iperf_results/${link}_tcp_reverse.txt
  iperf3 -c $SERVER_IP -u -b 50M -t 20  | tee iperf_results/${link}_udp_50M.txt   # shows jitter + loss
done
