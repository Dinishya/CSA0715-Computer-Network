"""B1 Alternative - one-way delay (synchronised clocks) vs RTT/2 on an asymmetric path."""
cases = [  # (name, upstream one-way ms, downstream one-way ms)
    ("symmetric", 25, 25),
    ("slow upload (ADSL/Wi-Fi uplink queueing)", 80, 20),
]
for name, up, down in cases:
    rtt = up + down
    half = rtt / 2
    print(f"{name}: true up {up} ms, true down {down} ms, RTT {rtt} ms, RTT/2 = {half:.0f} ms")
    print(f"   error for upload  = {half-up:+.0f} ms ({(half-up)/up*100:+.0f} %)")
    print(f"   error for download= {half-down:+.0f} ms ({(half-down)/down*100:+.0f} %)")
