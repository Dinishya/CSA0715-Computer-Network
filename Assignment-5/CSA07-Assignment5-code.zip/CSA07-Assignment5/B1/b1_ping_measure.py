"""B1.1 - RTT, jitter and loss to three servers. Run it 3 times a day (morning/afternoon/evening).
Usage:  python b1_ping_measure.py            (Linux/macOS)
        python b1_ping_measure.py --windows  (Windows ping syntax)
Results are appended to b1_ping_results.csv. Also keep the raw ping/traceroute text files."""
import subprocess, re, sys, csv, datetime, statistics

# EDIT: pick one near, one medium, one far server
TARGETS = {"near": "8.8.8.8", "medium": "www.bbc.co.uk", "far": "www.usyd.edu.au"}
COUNT = 20
win = "--windows" in sys.argv

def ping(host):
    cmd = ["ping", "-n" if win else "-c", str(COUNT), host]
    out = subprocess.run(cmd, capture_output=True, text=True).stdout
    open(f"raw_ping_{host}_{datetime.datetime.now():%H%M}.txt", "w").write(out)
    rtts = [float(x) for x in re.findall(r"time[=<]([\d.]+)\s*ms", out)]
    return rtts

def tracert(host):
    cmd = ["tracert" if win else "traceroute", host]
    out = subprocess.run(cmd, capture_output=True, text=True).stdout
    open(f"raw_traceroute_{host}_{datetime.datetime.now():%H%M}.txt", "w").write(out)

with open("b1_ping_results.csv", "a", newline="") as f:
    w = csv.writer(f)
    for label, host in TARGETS.items():
        rtts = ping(host)
        loss = (COUNT - len(rtts)) / COUNT * 100
        jitter = statistics.mean(abs(a - b) for a, b in zip(rtts, rtts[1:])) if len(rtts) > 1 else 0
        row = [datetime.datetime.now().isoformat(timespec="minutes"), label, host,
               min(rtts, default=0), statistics.mean(rtts) if rtts else 0, max(rtts, default=0),
               round(jitter, 2), loss]
        w.writerow(row)
        print(f"{label:<7}{host:<18} min {row[3]:.1f}  avg {row[4]:.1f}  max {row[5]:.1f} ms  jitter {row[6]} ms  loss {loss:.0f} %")
        tracert(host)
