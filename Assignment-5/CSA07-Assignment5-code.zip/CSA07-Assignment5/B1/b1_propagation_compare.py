"""B1.1 - compare measured minimum RTT with the propagation delay. EDIT the distances/RTTs."""
SPEED = 2e8   # m/s in fibre
rows = [  # (name, great-circle km, measured min RTT ms)  <-- replace with YOUR measurements
    ("near", 50, 4.0), ("medium", 8000, 140.0), ("far", 13000, 300.0)]
print(f"{'server':<8}{'km':>7}{'prop RTT ms':>13}{'min RTT ms':>12}{'excess ms':>11}{'path/straight':>15}")
for n, km, rtt in rows:
    prop_rtt = 2 * km * 1000 / SPEED * 1000
    print(f"{n:<8}{km:>7}{prop_rtt:>13.1f}{rtt:>12.1f}{rtt-prop_rtt:>11.1f}{rtt/prop_rtt:>15.2f}")
