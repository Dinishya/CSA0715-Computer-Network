"""B2 - discrete-event model of a 2 Mbps WAN link shared by a voice flow and a file download.
Compares FIFO against strict-priority queuing for voice. Pure Python, repeatable (fixed seed)."""
import heapq, random, statistics
random.seed(1)

def run(link_bps, n_calls, bg_mbps, priority, sim_s=20):
    events, t_free, q_voice, q_data = [], 0.0, [], []
    voice_delays, drops_v = [], 0
    # generate packets: (arrival time, kind, size bytes)
    pkts = []
    for c in range(n_calls):
        t = random.uniform(0, 0.02)
        while t < sim_s:
            pkts.append((t, "v", 200)); t += 0.02
    if bg_mbps:
        mean_gap = 1500 * 8 / (bg_mbps * 1e6)
        t = 0
        while t < sim_s:
            t += random.expovariate(1 / mean_gap); pkts.append((t, "d", 1500))
    pkts.sort()
    now, i, qv, qd, nd = 0.0, 0, [], [], 0
    LIMIT = 64  # packet buffer
    while i < len(pkts) or qv or qd:
        while i < len(pkts) and pkts[i][0] <= now:
            a, k, s = pkts[i]; i += 1
            if k == "v": qv.append((a, s))
            elif len(qd) + len(qv) < LIMIT: qd.append((a, s))
        if not qv and not qd:
            if i < len(pkts): now = max(now, pkts[i][0]); continue
            break
        if priority:
            src = qv if qv else qd
        else:  # FIFO: pick the older head packet
            src = qv if qv and (not qd or qv[0][0] <= qd[0][0]) else qd
        a, s = src.pop(0)
        now += s * 8 / link_bps
        if src is qv: voice_delays.append((now - a) * 1000)
        else: nd += s
    j = statistics.mean(abs(x - y) for x, y in zip(voice_delays, voice_delays[1:]))
    return statistics.mean(voice_delays), max(voice_delays), j, nd * 8 / sim_s / 1e6

print(f"{'scenario':<42}{'avg ms':>8}{'max ms':>8}{'jitter':>8}{'data Mbps':>10}")
for label, calls, bg, prio in [
    ("5 calls, no download", 5, 0, False),
    ("5 calls + 1.9 Mbps download, FIFO", 5, 1.9, False),
    ("5 calls + 1.9 Mbps download, PRIORITY", 5, 1.9, True),
    ("20 calls + 1.9 Mbps download, FIFO", 20, 1.9, False),
    ("20 calls + 1.9 Mbps download, PRIORITY", 20, 1.9, True)]:
    a, m, j, d = run(2e6, calls, bg, prio)
    print(f"{label:<42}{a:>8.1f}{m:>8.1f}{j:>8.1f}{d:>10.2f}")
