/* B2 (NS-3) - regional centre -> WAN -> server. Voice (UDP, G.711-like) + background TCP download.
 * Place in ns-3/scratch/ and run:
 *   ./ns3 run "scratch/ns3_company_network --bw=2Mbps --delay=20ms --users=5 --bg=1 --prio=0"
 *   ./ns3 run "scratch/ns3_company_network --bw=2Mbps --delay=20ms --users=5 --bg=1 --prio=1"
 * NOTE: written for ns-3.3x; check API names against your installed version. */
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/traffic-control-module.h"
#include "ns3/flow-monitor-module.h"
using namespace ns3;

int main(int argc, char *argv[]) {
  std::string bw = "2Mbps", delay = "20ms";
  uint32_t users = 5, bg = 1, prio = 0;
  CommandLine cmd;
  cmd.AddValue("bw", "WAN bandwidth", bw);
  cmd.AddValue("delay", "WAN delay", delay);
  cmd.AddValue("users", "number of voice calls", users);
  cmd.AddValue("bg", "1 = background TCP download", bg);
  cmd.AddValue("prio", "1 = priority queue (voice first)", prio);
  cmd.Parse(argc, argv);

  NodeContainer nodes; nodes.Create(2);           // 0 = regional centre, 1 = server
  PointToPointHelper p2p;
  p2p.SetDeviceAttribute("DataRate", StringValue(bw));
  p2p.SetChannelAttribute("Delay", StringValue(delay));
  NetDeviceContainer devs = p2p.Install(nodes);

  InternetStackHelper stack; stack.Install(nodes);
  TrafficControlHelper tch;
  if (prio) {   // 2 bands; packets with DSCP EF (TOS 0xb8) go to band 0
    uint16_t handle = tch.SetRootQueueDisc("ns3::PrioQueueDisc", "Priomap",
        StringValue("1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1"));
    TrafficControlHelper::ClassIdList cid = tch.AddQueueDiscClasses(handle, 2, "ns3::QueueDiscClass");
    tch.AddChildQueueDisc(handle, cid[0], "ns3::FifoQueueDisc");
    tch.AddChildQueueDisc(handle, cid[1], "ns3::FifoQueueDisc");
  } else {
    tch.SetRootQueueDisc("ns3::FifoQueueDisc");
  }
  tch.Install(devs);

  Ipv4AddressHelper ip; ip.SetBase("10.0.0.0", "255.255.255.0");
  Ipv4InterfaceContainer ifc = ip.Assign(devs);

  // Voice: 200-byte packets every 20 ms, one OnOff app per call
  for (uint32_t i = 0; i < users; i++) {
    uint16_t port = 5000 + i;
    OnOffHelper voice("ns3::UdpSocketFactory", InetSocketAddress(ifc.GetAddress(1), port));
    voice.SetAttribute("PacketSize", UintegerValue(160));      // + 40 B headers added by stack = ~200 B
    voice.SetAttribute("DataRate", StringValue("64kbps"));
    voice.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1]"));
    voice.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
    voice.SetAttribute("Tos", UintegerValue(0xb8));            // DSCP EF
    ApplicationContainer a = voice.Install(nodes.Get(0)); a.Start(Seconds(1)); a.Stop(Seconds(21));
    PacketSinkHelper sink("ns3::UdpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), port));
    sink.Install(nodes.Get(1)).Start(Seconds(0));
  }
  if (bg) {   // background file download: TCP bulk flow
    BulkSendHelper ftp("ns3::TcpSocketFactory", InetSocketAddress(ifc.GetAddress(1), 8000));
    ApplicationContainer a = ftp.Install(nodes.Get(0)); a.Start(Seconds(2)); a.Stop(Seconds(21));
    PacketSinkHelper sink("ns3::TcpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), 8000));
    sink.Install(nodes.Get(1)).Start(Seconds(0));
  }

  FlowMonitorHelper fm; Ptr<FlowMonitor> mon = fm.InstallAll();
  Simulator::Stop(Seconds(22)); Simulator::Run();

  Ptr<Ipv4FlowClassifier> cl = DynamicCast<Ipv4FlowClassifier>(fm.GetClassifier());
  for (auto &kv : mon->GetFlowStats()) {
    Ipv4FlowClassifier::FiveTuple t = cl->FindFlow(kv.first);
    auto &s = kv.second;
    if (s.rxPackets == 0) continue;
    std::cout << t.destinationPort << (t.destinationPort >= 5000 && t.destinationPort < 6000 ? " VOICE" : " DATA ")
              << "  loss=" << 100.0 * (s.txPackets - s.rxPackets) / s.txPackets << "%"
              << "  delay=" << 1000 * s.delaySum.GetSeconds() / s.rxPackets << "ms"
              << "  jitter=" << 1000 * s.jitterSum.GetSeconds() / (s.rxPackets > 1 ? s.rxPackets - 1 : 1) << "ms"
              << "  thr=" << s.rxBytes * 8.0 / 19.0 / 1e6 << "Mbps\n";
  }
  Simulator::Destroy();
  return 0;
}
