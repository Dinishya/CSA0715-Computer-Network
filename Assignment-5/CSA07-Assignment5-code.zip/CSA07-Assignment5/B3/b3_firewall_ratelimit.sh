#!/bin/bash
# B3.3 - corrected firewall + rate limiting. ISOLATED LAB SERVER ONLY (never a real site).
# Run on the lab server as root.
iptables -F; iptables -P INPUT DROP
iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT     # stateful return traffic
iptables -A INPUT -p tcp --dport 443 -j ACCEPT                       # rule 1
iptables -A INPUT -p tcp --dport 22 -s 10.1.0.0/16 -j ACCEPT         # rule 2
iptables -A INPUT -p tcp --dport 22 -j DROP                          # rule 3
iptables -A INPUT -p udp --dport 53 -j ACCEPT                        # rule 4  (rule 5 = default DROP)
iptables -L -n -v --line-numbers | tee firewall_rules_output.txt

# ---- test from another lab machine ----
#   nmap -p 22,80,443 <server>                       -> 22 filtered from outside, 443 open, 80 filtered
#   ssh user@<server>   from 10.1.x.x  -> works ; from other address -> times out

# ---- flood test: WITHOUT rate limiting (lab web server on :80/:443 allowed temporarily) ----
#   ab -n 20000 -c 200 http://<server>/ | tee flood_no_limit.txt        (Apache Bench: response time)
# ---- WITH rate limiting ----
iptables -I INPUT 3 -p tcp --dport 443 -m hashlimit --hashlimit-name web --hashlimit-above 50/sec \
         --hashlimit-burst 100 --hashlimit-mode srcip -j DROP
sysctl -w net.ipv4.tcp_syncookies=1
#   ab -n 20000 -c 200 https://<server>/ | tee flood_with_limit.txt
#   Meanwhile from a normal client:  curl -w "%{time_total}\n" -o /dev/null -s https://<server>/
