"""B3 - model values to compare with your iperf3 measurements.
TCP throughput under loss (Mathis): rate = MSS * 1.22 / (RTT * sqrt(p)), also capped by window/RTT and link rate."""
import math
MSS, LINK, WIN = 1460 * 8, 100e6, 64 * 1024 * 8
print("--- B3.1 delay (loss 0) : window-limited by 64 KB ---")
for d in (50, 150, 300):
    rtt = 2 * d / 1000
    print(f"one-way delay {d:>3} ms RTT {rtt*1000:>4.0f} ms -> max TCP {min(LINK, WIN/rtt)/1e6:6.2f} Mbps")
print("--- B3.1 loss (RTT 40 ms) ---")
rtt = 0.040
for p in (0.01, 0.05, 0.10):
    thr = min(LINK, WIN / rtt, MSS * 1.22 / (rtt * math.sqrt(p)))
    print(f"loss {p*100:>4.0f} % -> TCP approx {thr/1e6:6.2f} Mbps")
print("--- B3.2 window vs BDP (RTT 80 ms, 100 Mbps link) ---")
rtt = 0.080
for w in (64e3, 256e3, 1e6, 10e6):
    print(f"window {w/1000:>7.0f} KB -> {min(LINK, w*8/rtt)/1e6:6.2f} Mbps")
