#!/bin/bash
# B3.1 - delay and loss with tc netem (Linux, run as root, ISOLATED LAB ONLY)
# Server:  iperf3 -s      Client: this script. IFACE = the client's lab interface.
IFACE=${1:-eth0}; SERVER=${2:-192.168.1.10}
mkdir -p netem_results
for delay in 50 150 300; do
  tc qdisc replace dev $IFACE root netem delay ${delay}ms
  echo "== delay ${delay} ms =="; ping -c 10 $SERVER | tail -2 | tee netem_results/delay_${delay}_ping.txt
  iperf3 -c $SERVER -t 15 | tee netem_results/delay_${delay}_tcp.txt
  iperf3 -c $SERVER -u -b 80k -t 15 | tee netem_results/delay_${delay}_voice_udp.txt   # voice-like flow: jitter/loss
done
for loss in 1 5 10; do
  tc qdisc replace dev $IFACE root netem loss ${loss}%
  echo "== loss ${loss} % =="
  iperf3 -c $SERVER -t 15 | tee netem_results/loss_${loss}_tcp.txt
  iperf3 -c $SERVER -u -b 80k -t 15 | tee netem_results/loss_${loss}_voice_udp.txt
done
tc qdisc del dev $IFACE root
