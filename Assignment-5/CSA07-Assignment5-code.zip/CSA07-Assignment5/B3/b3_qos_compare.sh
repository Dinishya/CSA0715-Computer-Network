#!/bin/bash
# B3 Alternative - strict priority (EF) vs weighted fair queuing for voice. Lab router/Linux box, run as root.
IFACE=${1:-eth1}
# --- Policy 1: strict priority (voice = UDP 5060-5100 / DSCP EF) ---
tc qdisc replace dev $IFACE root handle 1: prio bands 2 priomap 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
tc filter add dev $IFACE parent 1: protocol ip prio 1 u32 match ip tos 0xb8 0xfc flowid 1:1
echo "Policy: STRICT PRIORITY"
#   run: iperf3 -c SERVER -t 30 &  (download)  and  ping -c 50 SERVER  or  iperf3 -u -b 80k  (voice) -> record delay + TCP Mbps
# --- Policy 2: weighted fair queuing (HTB 70% voice class / 30% data, borrowing allowed) ---
tc qdisc replace dev $IFACE root handle 1: htb default 20
tc class add dev $IFACE parent 1: classid 1:1 htb rate 2mbit
tc class add dev $IFACE parent 1:1 classid 1:10 htb rate 1400kbit ceil 2mbit prio 0
tc class add dev $IFACE parent 1:1 classid 1:20 htb rate 600kbit  ceil 2mbit prio 1
tc qdisc add dev $IFACE parent 1:20 handle 20: sfq perturb 10
tc filter add dev $IFACE parent 1: protocol ip prio 1 u32 match ip tos 0xb8 0xfc flowid 1:10
echo "Policy: WEIGHTED FAIR QUEUING"
#   repeat the same measurements
