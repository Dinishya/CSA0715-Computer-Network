#!/bin/bash
# B3.2 - small vs large TCP window on a long-delay link (80 ms RTT => 40 ms each way)
IFACE=${1:-eth0}; SERVER=${2:-192.168.1.10}
tc qdisc replace dev $IFACE root netem delay 40ms          # run the same on the server side for a true 80 ms RTT
for w in 64K 256K 1M 10M; do
  echo "== window $w =="; iperf3 -c $SERVER -t 15 -w $w | tee window_$w.txt
done
tc qdisc del dev $IFACE root
# Compare with A1.2: 64 KB / 80 ms = 6.55 Mbps; the window must reach BDP to fill the link.
