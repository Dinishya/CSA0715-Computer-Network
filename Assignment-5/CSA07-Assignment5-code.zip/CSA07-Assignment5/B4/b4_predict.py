"""B4 - predict delay/jitter/loss for another continent and for double the users.
Replace INPUT values with YOUR B1/B2/B3 measurements."""
import math
SPEED = 2e8
# ---- INPUT (your measurements) ----
local_rtt_ms = 40          # measured RTT to the Indian server
local_jitter = 5           # ms
base_loss = 0.2            # %
users_now, users_next = 1000, 2000
link_mbps, per_user_kbps = 1000, 250      # evening average
# ---- 1. another continent ----
for name, km in (("Europe (London)", 8200), ("North America (New York)", 12500), ("Australia (Sydney)", 9200)):
    prop = 2 * km * 1000 / SPEED * 1000
    rtt = prop * 1.7 + 10       # real path ~1.7x great-circle + equipment (use your B1 ratio)
    print(f"{name:<26} predicted RTT {rtt:6.0f} ms, one-way {rtt/2:5.0f} ms -> live class "
          f"{'OK' if rtt/2 < 150 else 'too slow'} (target < 150 ms one-way)")
# ---- 2. double the users: M/M/1 queue growth ----
for u in (users_now, users_next):
    util = u * per_user_kbps / 1000 / link_mbps
    qfactor = 1 / (1 - util) if util < 1 else float("inf")
    print(f"{u} users: utilisation {util*100:.0f} %, queuing delay x{qfactor:.1f}, "
          f"jitter ~{local_jitter*qfactor:.1f} ms")
print("Rule of thumb: keep utilisation below 70-80 % or voice/video need priority queuing.")
# ---- 3. regional server alternative ----
far_rtt = 300
print(f"Regional server: RTT {far_rtt} ms -> {20} ms, one-way gain {(far_rtt-20)/2:.0f} ms")
