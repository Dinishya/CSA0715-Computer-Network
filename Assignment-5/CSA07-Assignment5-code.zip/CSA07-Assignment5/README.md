# CSA07 - Computer Networks - Assignment 5 (CO5)
Name: ________   Register Number: ________   OS: ________   Python: ________   Packet Tracer / NS-3 version: ________

Repository name to create on GitHub: `CSA07-<RegisterNumber>-Assignment5` (share with the faculty).

| Folder | Task | Programs / files | Run |
|---|---|---|---|
| A1 | Delay, BDP, targets | a1_delay_calc.py, a1_targets.md | `python A1/a1_delay_calc.py` |
| A2 | Application protocols | a2_smtp_client.py, a2_mailbox_estimate.py, a2_ftp_snmp_dns_commands.md | see file headers |
| A3 | P2P, VoIP, overlays | a3_distribution_time.py, a3_voip_bandwidth.py | `python A3/...` |
| A4 | Firewall | firewall.py (Complete the Code), corrected_rules.txt | `python A4/firewall.py` |
| A5 | DoS sizing | a5_syn_flood_calc.py | `python A5/a5_syn_flood_calc.py` |
| B1 | Real measurements | b1_ping_measure.py, b1_iperf3_commands.sh, b1_capture_metrics.py, b1_propagation_compare.py, b1_oneway_vs_rtt.py | see file headers |
| B2 | Simulation | ns3_company_network.cc, packet_tracer_setup.txt, b2_queue_sim.py | NS-3 / Packet Tracer / Python |
| B3 | Stress and attack | b3_netem.sh, b3_window.sh, b3_firewall_ratelimit.sh, b3_qos_compare.sh, b3_mathis_model.py | Linux lab, root |
| B4 | Decision | b4_predict.py | `python B4/b4_predict.py` |

Add to each task folder: your own outputs (`output.txt`), Wireshark `.pcapng` files, screenshots and `.pkt` files.
**Ethics:** flood/DoS tests only on your own isolated lab network or simulator.

## Result notes (fill after running)
- A1: ...   - B1: ...   - B3: ...
