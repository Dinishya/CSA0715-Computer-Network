#!/bin/bash
# One commit per task (the faculty checks the history). Run once, then `git push`.
git init 2>/dev/null
for t in A1 A2 A3 A4 A5 B1 B2 B3 B4; do
  git add $t && git commit -m "Add $t code, outputs and notes" 2>/dev/null
done
git add README.md commit_each_task.sh && git commit -m "Add README"
echo "Now: git remote add origin https://github.com/<you>/CSA07-<RegNo>-Assignment5.git && git push -u origin main"
